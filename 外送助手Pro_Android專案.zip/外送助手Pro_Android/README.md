# 外送助手 Pro Android App

這是一個原生 Android WebView App，內含目前的「外送助手 Pro」網頁版本。

## 目前包含
- 最多 4 筆獨立計時訂單
- 起始金額可修改，預設 NT$45
- 依 245 元／時自動計算保障金額
- 訂單可「修改金額」且不重設開始時間
- 「配送完成」自動進歷史訂單
- 低調的「放棄此單」功能與自訂確認視窗
- 歷史訂單：本日／本週、日期前後切換、今日／本週收入與工作時間
- 夾單重疊工作時間只計算一次
- 不含備份／匯入／匯出功能
- 資料使用手機 WebView 的 localStorage 保存

## 用 Android Studio 建立 APK
1. 解壓縮本專案。
2. 用 Android Studio 開啟「外送助手Pro_Android」資料夾。
3. 等待 Gradle Sync 完成。
4. 選擇 `Build > Build APK(s)`。
5. Debug APK 會產生在 `app/build/outputs/apk/debug/app-debug.apk`。

本環境沒有完整 Android SDK/Gradle，因此這裡無法直接編譯 APK；專案本身已整理好，可直接交給 Android Studio 編譯。
